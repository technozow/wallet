# ZOW Wallet App

Initial version of wallet-based application with R/C and V/C logic.