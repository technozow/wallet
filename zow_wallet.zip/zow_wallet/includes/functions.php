<?php
// Wallet transaction logic

<?php
require_once 'db.php';

function isFirstDeposit($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM deposits WHERE user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn() == 0;
}
?>

?>