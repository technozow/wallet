<?php
// Wallet display (R/C and V/C)
?>