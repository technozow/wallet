<?php
// Buy ZOW coins functionality
?>