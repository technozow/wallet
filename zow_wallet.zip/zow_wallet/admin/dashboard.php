<?php
include 'includes/auth.php'; // Protect this page

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', sans-serif;
    }

    body {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background-color: #f4f4f4;
    }

    header {
      background-color: #111;
      color: white;
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header .logo {
      font-size: 22px;
      font-weight: bold;
    }

    header .user-profile {
      font-size: 14px;
    }

    .dashboard {
      display: flex;
      flex: 1;
    }

    .sidebar {
      width: 220px;
      background-color: #222;
      padding-top: 20px;
      color: #fff;
      height: 100%;
    }

    .sidebar a {
      display: block;
      padding: 12px 20px;
      color: #fff;
      text-decoration: none;
      transition: background 0.3s ease;
    }

    .sidebar a:hover {
      background-color: #444;
    }

    .main-content {
      flex: 1;
      padding: 30px;
      background-color: #fff;
      overflow-y: auto;
    }

    .main-content h1 {
      margin-bottom: 20px;
    }

    .card {
      padding: 20px;
      background-color: #f7f7f7;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
  <!-- Top Navbar -->
  <header>
    <div class="logo">⚙️ ZOW Wallet Admin</div>
    <div class="user-profile">👤 Admin | Logout</div>
  </header>

  <!-- Sidebar + Main Layout -->
  <div class="dashboard">
    <!-- Sidebar -->
    <nav class="sidebar">
      <a href='admin-qr-upload.php'>Update QR Code</a><br>";
      <a href='#'>Update Bank Details</a><br>";
      <!-- Add more admin sections here -->
    </nav>

    <!-- Main Content -->
    <main class="main-content">
      <h1>Welcome to the Admin Dashboard</h1>
      <div class="card">
        <p>Select an option from the sidebar to manage wallet settings.</p>
      </div>
    </main>
  </div>
  
</body>
</html>
