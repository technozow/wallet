<?php
include '../includes/auth.php';
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['qr'])) {
    $target = "upload/" . basename($_FILES['qr']['name']);
    move_uploaded_file($_FILES['qr']['tmp_name'], $target);

    // Insert new QR code
    $stmt = $conn->prepare("INSERT INTO payment_details (qr_code_path, is_active) VALUES (:path, 0)");
    $stmt->bindValue(':path', $target);
    $stmt->execute();

    echo "<p style='color:lime;'>QR Code uploaded!</p>";
}

if (isset($_GET['activate'])) {
    $id = intval($_GET['activate']);

    // Deactivate all
    $conn->query("UPDATE payment_details SET is_active = 0");

    // Get the QR code path of the selected ID
    $stmt = $conn->prepare("SELECT qr_code_path FROM payment_details WHERE id = :id");
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $qrCode = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($qrCode) {
        // Activate the selected QR code
        $stmt = $conn->prepare("UPDATE payment_details SET is_active = 1 WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        echo "<p style='color:gold;'>QR Code #$id is now active!</p>";
    } else {
        echo "<p style='color:red;'>QR Code not found.</p>";
    }
}

// Get active QR code
$activeQR = $conn->query("SELECT * FROM payment_details WHERE is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// Get all QR codes
$allQRs = $conn->query("SELECT * FROM payment_details ORDER BY id DESC");
?>

<h2>Upload QR Code</h2>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="qr" required>
    <button type="submit">Upload</button>
</form>

<hr>

<h2>Active QR Code</h2>
<?php if ($activeQR): ?>
    <img src="<?= $activeQR['qr_code_path'] ?>" alt="Active QR Code" style="width:200px; border:2px solid lime; border-radius:8px;">
<?php else: ?>
    <p>No active QR code yet.</p>
<?php endif; ?>

<hr>

<h2>All Uploaded QR Codes</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>QR Image</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php while($qr = $allQRs->fetch(PDO::FETCH_ASSOC)) : ?>
    <tr>
        <td><?= $qr['id'] ?></td>
        <td><img src="<?= $qr['qr_code_path'] ?>" style="width:100px;"></td>
        <td><?= $qr['is_active'] ? "<span style='color:lime;'>Active</span>" : "Inactive" ?></td>
        <td>
            <?php if (!$qr['is_active']): ?>
                <a href="?activate=<?= $qr['id'] ?>">Set Active</a>
            <?php else: ?>
                ✔
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
