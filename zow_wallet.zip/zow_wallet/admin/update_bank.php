<?php
include 'includes/auth.php';
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $upi = $_POST['upi'];
  $bank = $_POST['bank'];
  $acc = $_POST['acc'];
  $ifsc = $_POST['ifsc'];

  $stmt = $conn->prepare("UPDATE payment_details SET upi_id=?, bank_name=?, account_number=?, ifsc_code=?");
  $stmt->bind_param("ssss", $upi, $bank, $acc, $ifsc);
  $stmt->execute();

  echo "Bank details updated!";
}
?>

<form method="POST">
  <input type="text" name="upi" placeholder="UPI ID" required><br>
  <input type="text" name="bank" placeholder="Bank Name" required><br>
  <input type="text" name="acc" placeholder="Account Number" required><br>
  <input type="text" name="ifsc" placeholder="IFSC Code" required><br>
  <button type="submit">Update</button>
</form>
